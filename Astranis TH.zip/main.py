from mainSimulation import mainSimulation
from monteCarlo import MonteCarlo

#Uncomment the following if you want to run the Monte-Carlo in the report with 10 samples
#MonteCarlo()

#Uncomment if you want to run the main simulation with nominal parameters
#mainSimulation(enablePlots=True)